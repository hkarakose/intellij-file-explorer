package org.easymock.classextension.internal;

import org.objenesis.ObjenesisHelper;

public class ObjenesisClassInstantiator implements IClassInstantiator {

    public Object newInstance(Class clazz) throws InstantiationException {
        return ObjenesisHelper.newInstance(clazz);
    }

}
